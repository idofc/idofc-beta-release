package com.idofc.dto;

public class PrayerRequestDto {
	private String requestSubmittedAs;
	private String prayerRequest;

	public String getRequestSubmittedAs() {
		return requestSubmittedAs;
	}

	public void setRequestSubmittedAs(String requestSubmittedAs) {
		this.requestSubmittedAs = requestSubmittedAs;
	}

	public String getPrayerRequest() {
		return prayerRequest;
	}

	public void setPrayerRequest(String prayerRequest) {
		this.prayerRequest = prayerRequest;
	}

	@Override
	public String toString() {
		return "PrayerRequestDto [requestSubmittedAs=" + requestSubmittedAs + ", prayerRequest=" + prayerRequest + "]";
	}

}
