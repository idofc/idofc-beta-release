package com.idofc.dto;

import org.springframework.stereotype.Component;

@Component
public class ResponseDto {
	private Integer returnCode;
	private String returnMsg;

	public ResponseDto() {
		super();
	}

	public ResponseDto(Integer returnCode, String returnMsg) {
		super();
		this.returnCode = returnCode;
		this.returnMsg = returnMsg;
	}

	public Integer getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	@Override
	public String toString() {
		return "ResponseDto [returnCode=" + returnCode + ", returnMsg=" + returnMsg + "]";
	}

}
