package com.idofc.dto;

public class UserProfileDto {
	private String userFirstName;
	private String userLastName;
	private String userDisplayName;
	private String userEmail;
	private String userPass;
	private Boolean userActiveInd;
	private String userUniqueId;
	private String userRole;
	private String userTestimony;
	private String userBookProgress;

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserDisplayName() {
		return userDisplayName;
	}

	public void setUserDisplayName(String userDisplayName) {
		this.userDisplayName = userDisplayName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public Boolean getUserActiveInd() {
		return userActiveInd;
	}

	public void setUserActiveInd(Boolean userActiveInd) {
		this.userActiveInd = userActiveInd;
	}

	public String getUserUniqueId() {
		return userUniqueId;
	}

	public void setUserUniqueId(String userUniqueId) {
		this.userUniqueId = userUniqueId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserTestimony() {
		return userTestimony;
	}

	public void setUserTestimony(String userTestimony) {
		this.userTestimony = userTestimony;
	}



	public String getUserBookProgress() {
		return userBookProgress;
	}

	public void setUserBookProgress(String userBookProgress) {
		this.userBookProgress = userBookProgress;
	}

	@Override
	public String toString() {
		return "UserProfileDto [userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userDisplayName=" + userDisplayName + ", userEmail=" + userEmail + ", userPass=" + userPass
				+ ", userActiveInd=" + userActiveInd + ", userUniqueId=" + userUniqueId + ", userRole=" + userRole
				+ ", userTestimony=" + userTestimony + ", userBookProgress=" + userBookProgress + "]";
	}

}
