package com.idofc.dto;

public class ChainDto {
	private String userEmail;
	private String mentorDiscipleInd;
	private String pageStart;
	private String pageEnd;

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getMentorDiscipleInd() {
		return mentorDiscipleInd;
	}

	public void setMentorDiscipleInd(String mentorDiscipleInd) {
		this.mentorDiscipleInd = mentorDiscipleInd;
	}

	public String getPageStart() {
		return pageStart;
	}

	public void setPageStart(String pageStart) {
		this.pageStart = pageStart;
	}

	public String getPageEnd() {
		return pageEnd;
	}

	public void setPageEnd(String pageEnd) {
		this.pageEnd = pageEnd;
	}

	@Override
	public String toString() {
		return "ChainDto [userEmail=" + userEmail + ", mentorDiscipleInd=" + mentorDiscipleInd + ", pageStart="
				+ pageStart + ", pageEnd=" + pageEnd + "]";
	}

}
