package com.idofc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdofcApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdofcApplication.class, args);
	}
}
