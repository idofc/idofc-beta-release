package com.idofc.domain;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "PrayerRequest")
public class PrayerRequest {
	@Id
	private String id;
	private String userEmail;
	private String requestDisplayName;
	private String prayerRequest;
	@CreatedDate
	private Date createTimestamp;
	@LastModifiedDate
	private Date updateTimestamp;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getRequestDisplayName() {
		return requestDisplayName;
	}

	public void setRequestDisplayName(String requestDisplayName) {
		this.requestDisplayName = requestDisplayName;
	}

	public String getPrayerRequest() {
		return prayerRequest;
	}

	public void setPrayerRequest(String prayerRequest) {
		this.prayerRequest = prayerRequest;
	}

	public Date getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(Date createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	@Override
	public String toString() {
		return "PrayerRequest [id=" + id + ", userEmail=" + userEmail + ", requestDisplayName=" + requestDisplayName
				+ ", prayerRequest=" + prayerRequest + ", createTimestamp=" + createTimestamp + ", updateTimestamp="
				+ updateTimestamp + "]";
	}

}
