package com.idofc.domain;

import java.util.Date;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "MentorData")
public class MentorData {
	@Id
	private String id;
	private String userEmail;
	private Set<String> mentorEmailList;
	private Date createDate;
	private Date lastUpdateDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public Set<String> getMentorEmailList() {
		return mentorEmailList;
	}

	public void setMentorEmailList(Set<String> mentorEmailList) {
		this.mentorEmailList = mentorEmailList;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	@Override
	public String toString() {
		return "MentorData [id=" + id + ", userEmail=" + userEmail + ", mentorEmailList=" + mentorEmailList
				+ ", createDate=" + createDate + ", lastUpdateDate=" + lastUpdateDate + "]";
	}

}
