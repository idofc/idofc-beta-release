package com.idofc.repository;

import com.idofc.dto.UserProfileDto;

public interface CustomUserProfileRepository {
	public boolean updateActiveInd(String userEmail, String userUniqueId);
	public void updatePassword(String userEmail, String userPass);
	void updateProfile(UserProfileDto updateUserProfile);
}
