package com.idofc.repository;

import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.idofc.domain.UserProfile;
import com.idofc.dto.UserProfileDto;

public class UserProfileRepositoryImpl implements CustomUserProfileRepository {
	final static Logger LOG = Logger.getLogger(UserProfileRepositoryImpl.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public boolean updateActiveInd(String userEmail, String userUniqueId) {
		Update update = new Update();
		update.set("userActiveInd", true);
		update.set("userUniqueId", UUID.randomUUID().toString());
		Query query = new Query();
		query.addCriteria(Criteria.where("userEmail").is(userEmail));
		query.addCriteria(Criteria.where("userUniqueId").is(userUniqueId));
		if (mongoTemplate.find(query, UserProfile.class).size() > 0) {
			LOG.debug("User activation success");
			mongoTemplate.updateFirst(query, update, UserProfile.class);
			return true;
		} else {
			LOG.debug("User activation failed. User not found");
			return false;
		}
	}

	@Override
	public void updatePassword(String userEmail, String userPass) {
		Update update = new Update();
		update.set("userPass", userPass);
		Query query = new Query();
		query.addCriteria(Criteria.where("userEmail").is(userEmail));
		mongoTemplate.updateFirst(query, update, UserProfile.class);
	}

	@Override
	public void updateProfile(UserProfileDto updateUserProfile) {
		Update update = new Update();
		update.set("userFirstName", updateUserProfile.getUserFirstName());
		update.set("userLastName", updateUserProfile.getUserLastName());
		update.set("userDisplayName", updateUserProfile.getUserDisplayName());
		update.set("userTestimony", updateUserProfile.getUserTestimony());
		update.set("userBookProgress", updateUserProfile.getUserBookProgress());
		Query query = new Query();
		query.addCriteria(Criteria.where("userEmail").is(updateUserProfile.getUserEmail()));
		mongoTemplate.updateFirst(query, update, UserProfile.class);
	}

}
