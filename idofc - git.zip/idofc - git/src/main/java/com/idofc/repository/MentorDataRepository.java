package com.idofc.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.idofc.domain.MentorData;

public interface MentorDataRepository extends MongoRepository<MentorData, String>, CustomMentorDataRepository {
	MentorData findByUserEmail(String useremail);
}
