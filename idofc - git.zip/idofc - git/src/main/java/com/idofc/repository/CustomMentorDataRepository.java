package com.idofc.repository;

import java.util.List;

import com.idofc.dto.UserProfileDto;

public interface CustomMentorDataRepository {
	List<UserProfileDto> queryByUserEmail(String userEmail, String pageStart, String pageEnd);
}
