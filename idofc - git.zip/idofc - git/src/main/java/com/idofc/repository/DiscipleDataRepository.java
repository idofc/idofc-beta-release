package com.idofc.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.idofc.domain.DiscipleData;

@Repository
public interface DiscipleDataRepository extends MongoRepository<DiscipleData, String>, CustomDiscipleDataRepository {
	DiscipleData findByUserEmail(String useremail);
}
