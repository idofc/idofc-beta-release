package com.idofc.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.idofc.domain.MentorData;
import com.idofc.domain.UserProfile;
import com.idofc.dto.UserProfileDto;

public class MentorDataRepositoryImpl implements CustomMentorDataRepository {
	final static Logger LOG = Logger.getLogger(MentorDataRepositoryImpl.class);

	@Autowired
	private MongoTemplate template;

	@Override
	public List<UserProfileDto> queryByUserEmail(String userEmail, String pageStart, String pageEnd) {
		Query mentorQuery = new Query();
		mentorQuery.addCriteria(Criteria.where("userEmail").is(userEmail));
		MentorData mentorData = template.findOne(mentorQuery, MentorData.class);
		List<UserProfileDto> userProfileDtoList = new ArrayList<UserProfileDto>();
		int i = 0;
		int start = Integer.parseInt(pageStart);
		int end = Integer.parseInt(pageEnd);
		for (String mentorDataEmail : mentorData.getMentorEmailList()) {
			if ((i >= start) && (i <= end)) {
				Query userQuery = new Query();
				userQuery.addCriteria(Criteria.where("userEmail").is(mentorDataEmail));
				UserProfile mentorProfile = template.findOne(userQuery, UserProfile.class);
				UserProfileDto userProfileDto = new UserProfileDto();
				userProfileDto.setUserEmail(mentorDataEmail);
				if (mentorProfile != null) {
					userProfileDto.setUserUniqueId(mentorProfile.getUserUniqueId());
					userProfileDto.setUserDisplayName(mentorProfile.getUserDisplayName());
				}
				userProfileDtoList.add(userProfileDto);
			}
			i++;
		}
		return userProfileDtoList;
	}

}
