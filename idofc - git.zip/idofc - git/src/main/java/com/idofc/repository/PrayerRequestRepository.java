package com.idofc.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.idofc.domain.PrayerRequest;

public interface PrayerRequestRepository extends MongoRepository<PrayerRequest, String> {

}
