package com.idofc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.idofc.domain.DiscipleData;
import com.idofc.domain.UserProfile;
import com.idofc.dto.UserProfileDto;

public class DiscipleDataRepositoryImpl implements CustomDiscipleDataRepository {

	@Autowired
	private MongoTemplate template;

	@Override
	public List<UserProfileDto> queryByUserEmail(String userEmail, String pageStart, String pageEnd) {
		Query discipleQuery = new Query();
		discipleQuery.addCriteria(Criteria.where("userEmail").is(userEmail));
		DiscipleData discipleData = template.findOne(discipleQuery, DiscipleData.class);
		List<UserProfileDto> userProfileDtoList = new ArrayList<UserProfileDto>();
		int i = 0;
		int start = Integer.parseInt(pageStart);
		int end = Integer.parseInt(pageEnd);
		for (String discipleDataEmail : discipleData.getDiscipleEmailList()) {
			if ((i >= start) && (i <= end)) {
				Query userQuery = new Query();
				userQuery.addCriteria(Criteria.where("userEmail").is(discipleDataEmail));
				UserProfile discipleProfile = template.findOne(userQuery, UserProfile.class);
				UserProfileDto userProfileDto = new UserProfileDto();
				userProfileDto.setUserEmail(discipleDataEmail);
				if (discipleProfile != null) {
					userProfileDto.setUserUniqueId(discipleProfile.getUserUniqueId());
					userProfileDto.setUserDisplayName(discipleProfile.getUserDisplayName());
				}
				userProfileDtoList.add(userProfileDto);
			}
			i++;
		}
		return userProfileDtoList;
	}

}
