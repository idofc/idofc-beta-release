package com.idofc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.idofc.service.UserMongoService;

@Controller
public class WebController {
	final static Logger LOG = Logger.getLogger(WebController.class);

	@Autowired
	private UserMongoService userMongoService;

	@RequestMapping("/portal")
	public String showIndex() {
		LOG.debug("Showing Index");
		LOG.debug(SecurityContextHolder.getContext().getAuthentication().getName());
		return "portal";
	}

	@RequestMapping("/login")
	public String showLogin() {
		LOG.debug("Showing Login");
		return "login";
	}

	@RequestMapping("/register")
	public String showRegistration() {
		LOG.debug("Showing Registration");
		return "register";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return "redirect:/login?logout";
	}

	@RequestMapping(value = "/activate", method = RequestMethod.GET)
	public ModelAndView activateUser(@RequestParam("email") String userEmail,
			@RequestParam("token") String userUniqueId, ModelMap model) {
		LOG.debug("Activating " + userEmail + "/" + userUniqueId);
		if (userMongoService.activateUser(userEmail, userUniqueId) == true) {
			model.addAttribute("source", "activate-success");
		} else {
			model.addAttribute("source", "activate-failed");
		}
		return new ModelAndView("redirect:/login", model);
	}
}
