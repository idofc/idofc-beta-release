package com.idofc.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.idofc.domain.DiscipleData;
import com.idofc.domain.MentorData;
import com.idofc.domain.UserProfile;
import com.idofc.dto.ChainDto;
import com.idofc.dto.PrayerRequestDto;
import com.idofc.dto.ResponseDto;
import com.idofc.dto.UserProfileDto;
import com.idofc.profile.ImageProfile;
import com.idofc.service.MailService;
import com.idofc.service.UserMongoService;

@RestController
@RequestMapping("/api/")
public class ApiController {
	final static Logger LOG = Logger.getLogger(ApiController.class);

	@Autowired
	private UserMongoService userMongoService;
	@Autowired
	private MailService mailService;
	@Autowired
	private ImageProfile imageProfile;

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public ResponseDto testApiEndPoint() {
		LOG.info("Now Testing API Endpoint");
		return new ResponseDto(0, "Success reaching test");
	}

	@RequestMapping(value = "/securetest", method = RequestMethod.GET)
	public ResponseDto testSecureApiEndPoint() {
		LOG.info("Now Testing Secure API Endpoint");
		return new ResponseDto(0, "Success reaching secure test");
	}

	@RequestMapping(value = "/emailexists", method = RequestMethod.POST)
	public Boolean checkEmailExists(@RequestBody String email) {
		LOG.info("Checking if email exists " + email);
		return userMongoService.checkIfEmailExistsService(email);
	}

	@RequestMapping(value = "/adduser", method = RequestMethod.POST)
	public ResponseDto addUser(@RequestBody UserProfile userProfile) {
		LOG.info("Adding User " + userProfile);
		userProfile.setUserActiveInd(false);
		userProfile.setUserUniqueId(UUID.randomUUID().toString());
		userProfile.setUserRole("ROLE_USER");
		ResponseDto addUserResponseDto = userMongoService.addUser(userProfile);
		if (addUserResponseDto.getReturnCode() == 0) {
			LOG.info("Sending new user welcome Email for " + userProfile);
			addUserResponseDto = mailService.sendNewUserWelcomeEmail(userProfile);
			if (addUserResponseDto.getReturnCode() == 0) {
				return new ResponseDto(0, "User successfully added. Please check your email to confirm registration");
			}
		}
		return addUserResponseDto;
	}

	@RequestMapping(value = "/sendNewUserEmail", method = RequestMethod.GET)
	public ResponseDto sendNewUserEmail(@RequestBody UserProfile userProfile) {
		LOG.info("Sending new user welcome Email for " + userProfile);
		return mailService.sendNewUserWelcomeEmail(userProfile);
	}

	@RequestMapping(value = "/addmymentor", method = RequestMethod.POST)
	public ResponseDto addMyMentor(@RequestBody String mentorEmail) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Adding mentor for " + userEmail);
		return userMongoService.addMentorService(userEmail, mentorEmail);
	}

	@RequestMapping(value = "/getmymentorinfo", method = RequestMethod.POST)
	public MentorData getMyMentorInfo() {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Gettting mentor info for " + userEmail);
		return userMongoService.getAllMentors(userEmail);
	}

	@RequestMapping(value = "/getmentorinfo", method = RequestMethod.POST)
	public MentorData getMentorInfo(@RequestBody String userEmail) {
		LOG.info("Gettting mentor info for " + userEmail);
		return userMongoService.getAllMentors(userEmail);
	}

	@RequestMapping(value = "/updatemymentorlist", method = RequestMethod.POST)
	public ResponseDto updateMyMentorList(@RequestBody Set<String> mentorEmailList) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Updating mentor list for " + userEmail);
		LOG.info(mentorEmailList);
		return userMongoService.updateMentorList(userEmail, mentorEmailList);
	}

	@RequestMapping(value = "/addmydisciple", method = RequestMethod.POST)
	public ResponseDto addMyDisciple(@RequestBody String discipleEmail) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Adding disciple for " + userEmail);
		return userMongoService.addDiscipleService(userEmail, discipleEmail);
	}

	@RequestMapping(value = "/getmydiscipleinfo", method = RequestMethod.POST)
	public DiscipleData getMyDiscipleInfo() {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Gettting disciple info for " + userEmail);
		return userMongoService.getAllDisciples(userEmail);
	}

	@RequestMapping(value = "/getdiscipleinfo", method = RequestMethod.POST)
	public DiscipleData getDiscipleInfo(@RequestBody String userEmail) {
		LOG.info("Gettting disciple info for " + userEmail);
		return userMongoService.getAllDisciples(userEmail);
	}

	@RequestMapping(value = "/updatemydisciplelist", method = RequestMethod.POST)
	public ResponseDto updateMyDiscipleList(@RequestBody Set<String> discipleEmailList) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Updating disciple list for " + userEmail);
		LOG.info(discipleEmailList);
		return userMongoService.updateDiscipleList(userEmail, discipleEmailList);
	}

	@RequestMapping(value = "/updateuserprofile", method = RequestMethod.POST)
	public ResponseDto updateUserProfile(@RequestParam(value = "profilePic", required = false) MultipartFile profilePic,
			@RequestParam(value = "userProfile", required = true) String userProfile) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		Collection<? extends GrantedAuthority> userRole = SecurityContextHolder.getContext().getAuthentication()
				.getAuthorities();
		LOG.info("Updating user profile for " + userEmail);
		return userMongoService.updateUserProfile(userEmail, userRole, userProfile, profilePic);
	}

	@RequestMapping(value = "/getuserprofile", method = RequestMethod.GET)
	public UserProfile getMyUserProfile() {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Gettting user profile info for " + userEmail);
		return userMongoService.getUserDetailsService(userEmail);
	}

	@RequestMapping(value = "/getuserprofilebyemail", method = RequestMethod.POST)
	public UserProfile getMyUserProfileByEmail(@RequestBody String userEmail) {
		LOG.info("Gettting user profile info for " + userEmail);
		return userMongoService.getUserDetailsService(userEmail);
	}

	@RequestMapping(value = "/getuserprofilechain", method = RequestMethod.POST)
	public List<UserProfileDto> getUserProfilesForChain(@RequestBody ChainDto chainDto) {
		LOG.info("Gettting details for " + chainDto);
		return userMongoService.getUserProfilesForChainService(chainDto);
	}

	@RequestMapping(value = "/updatepassword", method = RequestMethod.POST)
	public ResponseDto updatePassword(@RequestBody String password) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Updating password for " + userEmail);
		return userMongoService.updatePasswordService(userEmail, password);
	}

	@RequestMapping(value = "/profilepic", method = RequestMethod.GET)
	public void getProfilePic(@RequestParam(value = "id", defaultValue = "default") String id,
			HttpServletResponse response) throws IOException {
		LOG.info("Getting profile pic for " + id);
		LOG.info("Location is - " + imageProfile.getImageStoreLocation() + id + ".jpg");
		ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();

		File imageFile = new File(imageProfile.getImageStoreLocation() + id + ".jpg");

		if (!(imageFile.exists())) {
			LOG.info("Getting default file");
			imageFile = new File(imageProfile.getImageStoreLocation() + "default.jpg");
		}
		try {
			BufferedImage image = ImageIO.read(imageFile);
			ImageIO.write(image, "jpeg", jpegOutputStream);
		} catch (IllegalArgumentException e) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
		} catch (Exception e) {
			LOG.error("Exception occurred during getting file");
			LOG.error(e);
			response.sendError(HttpServletResponse.SC_NO_CONTENT);
		}

		byte[] imgByte = jpegOutputStream.toByteArray();

		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType("image/jpeg");
		ServletOutputStream responseOutputStream = response.getOutputStream();
		responseOutputStream.write(imgByte);
		responseOutputStream.flush();
		responseOutputStream.close();
	}

	@RequestMapping(value = "/submitprayerrequest", method = RequestMethod.POST)
	public ResponseDto submitMyPrayerRequest(@RequestBody PrayerRequestDto prayerRequestDto) {
		String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
		LOG.info("Creating prayer request for " + userEmail);
		return userMongoService.submitPrayerRequestService(userEmail, prayerRequestDto);
	}
}
