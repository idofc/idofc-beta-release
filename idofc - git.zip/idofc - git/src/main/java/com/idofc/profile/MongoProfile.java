package com.idofc.profile;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class MongoProfile {
	private Map<String, String> mongoHostMap;
	private String mongoUser;
	private String mongoPass;
	private String mongoAuthDb;
	private String mongoDataDb;

	public Map<String, String> getMongoHostMap() {
		return mongoHostMap;
	}

	public void setMongoHostMap(Map<String, String> mongoHostMap) {
		this.mongoHostMap = mongoHostMap;
	}

	public String getMongoUser() {
		return mongoUser;
	}

	public void setMongoUser(String mongoUser) {
		this.mongoUser = mongoUser;
	}

	public String getMongoPass() {
		return mongoPass;
	}

	public void setMongoPass(String mongoPass) {
		this.mongoPass = mongoPass;
	}

	public String getMongoAuthDb() {
		return mongoAuthDb;
	}

	public void setMongoAuthDb(String mongoAuthDb) {
		this.mongoAuthDb = mongoAuthDb;
	}

	public String getMongoDataDb() {
		return mongoDataDb;
	}

	public void setMongoDataDb(String mongoDataDb) {
		this.mongoDataDb = mongoDataDb;
	}

	@Override
	public String toString() {
		return "MongoConfig [mongoHostMap=" + mongoHostMap + ", mongoUser=" + mongoUser + ", mongoPass=" + mongoPass
				+ ", mongoAuthDb=" + mongoAuthDb + ", mongoDataDb=" + mongoDataDb + "]";
	}

}
