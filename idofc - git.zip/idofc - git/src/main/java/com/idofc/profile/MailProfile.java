package com.idofc.profile;

import java.util.Properties;

import org.springframework.stereotype.Component;

@Component
public class MailProfile {
	private String mailHost;
	private Integer mailPort;
	private String mailUserName;
	private String mailPassword;
	private Properties javaMailProperties;
	private String mailFrom;
	private String mailReplyTo;

	public String getMailHost() {
		return mailHost;
	}

	public void setMailHost(String mailHost) {
		this.mailHost = mailHost;
	}

	public Integer getMailPort() {
		return mailPort;
	}

	public void setMailPort(Integer mailPort) {
		this.mailPort = mailPort;
	}

	public String getMailUserName() {
		return mailUserName;
	}

	public void setMailUserName(String mailUserName) {
		this.mailUserName = mailUserName;
	}

	public String getMailPassword() {
		return mailPassword;
	}

	public void setMailPassword(String mailPassword) {
		this.mailPassword = mailPassword;
	}

	public Properties getJavaMailProperties() {
		return javaMailProperties;
	}

	public void setJavaMailProperties(Properties javaMailProperties) {
		this.javaMailProperties = javaMailProperties;
	}

	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public String getMailReplyTo() {
		return mailReplyTo;
	}

	public void setMailReplyTo(String mailReplyTo) {
		this.mailReplyTo = mailReplyTo;
	}

	@Override
	public String toString() {
		return "MailProfile [mailHost=" + mailHost + ", mailPort=" + mailPort + ", mailUserName=" + mailUserName
				+ ", mailPassword=" + mailPassword + ", javaMailProperties=" + javaMailProperties + ", mailFrom="
				+ mailFrom + ", mailReplyTo=" + mailReplyTo + "]";
	}

}
