package com.idofc.profile;

import org.springframework.stereotype.Component;

@Component
public class ImageProfile {
	private String imageStoreLocation;

	public String getImageStoreLocation() {
		return imageStoreLocation;
	}

	public void setImageStoreLocation(String imageStoreLocation) {
		this.imageStoreLocation = imageStoreLocation;
	}

}
