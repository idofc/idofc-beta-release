package com.idofc.profile;

public class AppConstants {
	// Email Constants
	public static final String newUserWelcomeSubject = "Welcome to iDofC";
}
