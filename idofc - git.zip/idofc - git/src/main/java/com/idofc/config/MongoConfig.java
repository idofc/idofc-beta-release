package com.idofc.config;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.authentication.UserCredentials;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.idofc.profile.MongoProfile;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;

@Configuration
public class MongoConfig extends AbstractMongoConfiguration {
	final static Logger LOG = Logger.getLogger(MongoConfig.class);

	@Autowired
	private MongoProfile mongoProfile;

	@Override
	protected String getDatabaseName() {
		return mongoProfile.getMongoDataDb();
	}

	@Override
	public Mongo mongo() throws Exception {
		LOG.debug("Now connecting to Mongo");
		return new MongoClient("127.0.0.1", 27017);
	}

	@Bean
	public MongoDbFactory mongoDbFactory() throws Exception {
		UserCredentials userCredentials = new UserCredentials("admin", "admin");
		return new SimpleMongoDbFactory(new Mongo(), "test", userCredentials);
	}

	@Override
	protected String getMappingBasePackage() {
		return "com.idofc.domain";
	}

}
