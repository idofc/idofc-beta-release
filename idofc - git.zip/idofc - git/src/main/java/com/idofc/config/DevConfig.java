package com.idofc.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.idofc.profile.ImageProfile;
import com.idofc.profile.MailProfile;
import com.idofc.profile.MongoProfile;

@Configuration
@Profile("dev")
@PropertySources({ @PropertySource("classpath:/properties/dev.properties") })
public class DevConfig extends WebMvcConfigurerAdapter {
	final static Logger LOG = Logger.getLogger(DevConfig.class);

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/**").addResourceLocations("classpath:/templates/");
	}

	@Bean
	public MongoProfile mongoProfile(@Value("${MONGO_HOST_LIST}") String mongoHostListString,
			@Value("${MONGO_USER}") String mongoUser, @Value("${MONGO_PASS}") String mongoPass,
			@Value("${MONGO_AUTH_DB}") String mongoAuthDb, @Value("${MONGO_DATA_DB}") String mongoDataDb) {
		LOG.debug("Setting up Mongo Profile");
		MongoProfile mongoProfile = new MongoProfile();
		Map<String, String> mongoHostMap = new HashMap<String, String>();
		List<String> mongoHostList = Lists.newArrayList(Splitter.on(",").split(mongoHostListString));
		for (String mongoHost : mongoHostList) {
			List<String> mongoHostDetail = Lists.newArrayList(Splitter.on(":").split(mongoHost));
			mongoHostMap.put(mongoHostDetail.get(0), mongoHostDetail.get(1));
		}
		mongoProfile.setMongoHostMap(mongoHostMap);
		mongoProfile.setMongoAuthDb(mongoAuthDb);
		mongoProfile.setMongoUser(mongoUser);
		mongoProfile.setMongoPass(mongoPass);
		mongoProfile.setMongoDataDb(mongoDataDb);
		return mongoProfile;
	}

	@Bean
	public MailProfile mailProfile(@Value("${MAIL_HOST_NAME}") String mailHost, @Value("${MAIL_PORT}") String mailPort,
			@Value("${MAIL_USER}") String mailUser, @Value("${MAIL_PASS}") String mailPass,
			@Value("${MAIL_FROM}") String mailFrom, @Value("${MAIL_REPLY_TO}") String mailReplyTo) {
		LOG.debug("Setting up Mail Profile");
		MailProfile mailProfile = new MailProfile();
		mailProfile.setMailHost(mailHost);
		mailProfile.setMailPort(Integer.parseInt(mailPort));
		mailProfile.setMailUserName(mailUser);
		mailProfile.setMailPassword(mailPass);
		Properties javaMailProperties = new Properties();
		javaMailProperties.put("mail.smtp.starttls.enable", "true");
		javaMailProperties.put("mail.smtp.auth", "true");
		javaMailProperties.put("mail.transport.protocol", "smtp");
		javaMailProperties.put("mail.debug", "true");
		mailProfile.setJavaMailProperties(javaMailProperties);
		mailProfile.setMailFrom(mailFrom);
		mailProfile.setMailReplyTo(mailReplyTo);
		return mailProfile;
	}
	
	@Bean
	public ImageProfile imageProfile(@Value("${IMAGE_STORE_LOCATION}") String imageStoreLocation){
		LOG.debug("Setting up Image Profile");
		ImageProfile imageProfile = new ImageProfile();
		imageProfile.setImageStoreLocation(imageStoreLocation);
		return imageProfile;
	}
}
