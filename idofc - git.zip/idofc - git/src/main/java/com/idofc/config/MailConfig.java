package com.idofc.config;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.idofc.profile.MailProfile;

@Configuration
public class MailConfig {
	@Autowired
	private MailProfile mailProfile;

	@Bean
	public JavaMailSender getMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(mailProfile.getMailHost());
		mailSender.setPort(mailProfile.getMailPort());
		mailSender.setUsername(mailProfile.getMailUserName());
		mailSender.setPassword(mailProfile.getMailPassword());
		mailSender.setJavaMailProperties(mailProfile.getJavaMailProperties());
		return mailSender;
	}

	@Bean
	public SimpleMailMessage emailTemplate() {
		SimpleMailMessage emailTemplate = new SimpleMailMessage();
		emailTemplate.setFrom(mailProfile.getMailFrom());
		emailTemplate.setReplyTo(mailProfile.getMailReplyTo());
		emailTemplate.setSentDate(new Date());
		return emailTemplate;
	}
}
