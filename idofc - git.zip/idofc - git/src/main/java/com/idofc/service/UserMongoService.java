package com.idofc.service;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.multipart.MultipartFile;

import com.idofc.domain.DiscipleData;
import com.idofc.domain.MentorData;
import com.idofc.domain.UserProfile;
import com.idofc.dto.ChainDto;
import com.idofc.dto.PrayerRequestDto;
import com.idofc.dto.ResponseDto;
import com.idofc.dto.UserProfileDto;

public interface UserMongoService {

	Boolean checkIfEmailExistsService(String email);

	ResponseDto addUser(UserProfile userProfile);

	boolean activateUser(String userEmail, String userUniqueId);

	MentorData getAllMentors(String userEmail);

	ResponseDto addMentorService(String userEmail, String mentorEmail);

	ResponseDto updateMentorList(String userEmail, Set<String> mentorEmailList);

	DiscipleData getAllDisciples(String userEmail);

	ResponseDto addDiscipleService(String userEmail, String discipleEmail);

	ResponseDto updateDiscipleList(String userEmail, Set<String> discipleEmailList);

	UserProfile getUserDetailsService(String userEmail);

	ResponseDto updateUserProfile(String userEmail, Collection<? extends GrantedAuthority> userRole, String userProfile,
			MultipartFile profilePic);

	ResponseDto updatePasswordService(String userEmail, String password);

	List<UserProfileDto> getUserProfilesForChainService(ChainDto chainDto);

	ResponseDto submitPrayerRequestService(String userEmail, PrayerRequestDto prayerRequestDto);

}
