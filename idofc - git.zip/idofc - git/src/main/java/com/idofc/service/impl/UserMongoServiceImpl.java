package com.idofc.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.idofc.domain.DiscipleData;
import com.idofc.domain.MentorData;
import com.idofc.domain.PrayerRequest;
import com.idofc.domain.UserProfile;
import com.idofc.dto.ChainDto;
import com.idofc.dto.PrayerRequestDto;
import com.idofc.dto.ResponseDto;
import com.idofc.dto.UserProfileDto;
import com.idofc.profile.ImageProfile;
import com.idofc.repository.DiscipleDataRepository;
import com.idofc.repository.MentorDataRepository;
import com.idofc.repository.PrayerRequestRepository;
import com.idofc.repository.UserProfileRepository;
import com.idofc.service.UserMongoService;

@Service
public class UserMongoServiceImpl implements UserMongoService {
	final static Logger LOG = Logger.getLogger(UserMongoServiceImpl.class);

	@Autowired
	private UserProfileRepository userProfileRepository;
	@Autowired
	private MentorDataRepository mentorDataRepository;
	@Autowired
	private DiscipleDataRepository discipleDataRepository;
	@Autowired
	private PrayerRequestRepository prayerRequestRepository;

	@Autowired
	private ImageProfile imageProfile;

	@Override
	public Boolean checkIfEmailExistsService(String email) {
		LOG.debug("Checking if email exists " + email);
		LOG.debug(userProfileRepository.findByUserEmail(email));
		return (userProfileRepository.findByUserEmail(email) == null) ? false : true;
	}

	@Override
	public ResponseDto addUser(UserProfile userProfile) {
		try {
			userProfileRepository.insert(userProfile);
			return new ResponseDto(0, "Successfully added user.");
		} catch (Exception e) {
			LOG.error("Error occurred during insert");
			LOG.error(e);
			return new ResponseDto(-1, "Error adding user. Please try later.");
		}
	}

	@Override
	public boolean activateUser(String userEmail, String userUniqueId) {
		return userProfileRepository.updateActiveInd(userEmail, userUniqueId);
	}

	@Override
	public MentorData getAllMentors(String userEmail) {
		return mentorDataRepository.findByUserEmail(userEmail);
	}

	@Override
	public ResponseDto addMentorService(String userEmail, String mentorEmail) {
		try {
			// Step 1 - Add mentor to current user
			LOG.debug("Step 1 - Adding " + mentorEmail + " as mentor for " + userEmail);
			addMentor(userEmail, mentorEmail);
			// Step 2 - Add current user as mentor's disciple
			LOG.debug("Step 2 - Adding " + userEmail + " as disciple for " + mentorEmail);
			addDisciple(mentorEmail, userEmail);
			return new ResponseDto(0, "Successfully added mentor.");
		} catch (Exception e) {
			LOG.error("Error occurred during insert of MentorData");
			LOG.error(e);
			return new ResponseDto(-1, "Error adding mentor. Please try later.");
		}
	}

	@Override
	public ResponseDto updateMentorList(String userEmail, Set<String> mentorEmailList) {
		LOG.debug("Resetting mentor list for " + userEmail);
		try {
			MentorData mentorData = mentorDataRepository.findByUserEmail(userEmail);
			Set<String> existingMentorEmailList = mentorData.getMentorEmailList();
			existingMentorEmailList.removeAll(mentorEmailList);
			// Step 1 - Remove current user as mentor's disciple
			for (String mentorEmail : existingMentorEmailList) {
				removeDisciple(mentorEmail, userEmail);
			}
			// Step 2 - Reset mentor email list
			mentorData.setMentorEmailList(mentorEmailList);
			mentorDataRepository.save(mentorData);
			return new ResponseDto(0, "Successfully saved mentor list.");
		} catch (Exception e) {
			LOG.error("Error occurred during updating mentor list of MentorData");
			LOG.error(e);
			return new ResponseDto(-1, "Error updating mentor list. Please try later.");
		}
	}

	@Override
	public DiscipleData getAllDisciples(String userEmail) {
		return discipleDataRepository.findByUserEmail(userEmail);
	}

	@Override
	public ResponseDto addDiscipleService(String userEmail, String discipleEmail) {
		try {
			// Step 1 - Add disciple to current user
			LOG.debug("Step 1 - Adding " + discipleEmail + " as disciple for " + userEmail);
			addDisciple(userEmail, discipleEmail);
			// Step 2 - Add current user as disciple's mentor
			LOG.debug("Step 2 - Adding " + userEmail + " as mentor for " + discipleEmail);
			addMentor(discipleEmail, userEmail);
			return new ResponseDto(0, "Successfully added disciple.");
		} catch (Exception e) {
			LOG.error("Error occurred during insert of DiscipleData");
			LOG.error(e);
			return new ResponseDto(-1, "Error adding disciple. Please try later.");
		}
	}

	@Override
	public ResponseDto updateDiscipleList(String userEmail, Set<String> discipleEmailList) {
		LOG.debug("Resetting disciple list for " + userEmail);
		try {
			DiscipleData discipleData = discipleDataRepository.findByUserEmail(userEmail);
			Set<String> existingDiscipleDataList = discipleData.getDiscipleEmailList();
			existingDiscipleDataList.removeAll(discipleEmailList);
			// Step 1 - Remove current user as disciple's mentor
			for (String discipleEmail : existingDiscipleDataList) {
				removeMentor(discipleEmail, userEmail);
			}
			// Step 2 - Reset disciple email list
			discipleData.setDiscipleEmailList(discipleEmailList);
			discipleDataRepository.save(discipleData);
			return new ResponseDto(0, "Successfully saved disciple list.");
		} catch (Exception e) {
			LOG.error("Error occurred during updating disciple list of DiscipleData");
			LOG.error(e);
			return new ResponseDto(-1, "Error updating disciple list. Please try later.");
		}
	}

	@Override
	public UserProfile getUserDetailsService(String userEmail) {
		LOG.debug("Getting user details for " + userEmail);
		return userProfileRepository.findByUserEmail(userEmail);
	}

	@Override
	public ResponseDto updateUserProfile(String userEmail, Collection<? extends GrantedAuthority> userRole,
			String userProfile, MultipartFile profilePic) {
		LOG.debug("Updating user details for " + userEmail);
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			UserProfileDto updateUserProfile = mapper.readValue(userProfile, UserProfileDto.class);
			if (!(userEmail.equals(updateUserProfile.getUserEmail()))) {
				return new ResponseDto(-1, "Security violation. User does not have proper privileges");
			}
			if (profilePic != null) {
				LOG.debug(imageProfile.getImageStoreLocation());
				profilePic.transferTo(
						new File(imageProfile.getImageStoreLocation() + updateUserProfile.getUserUniqueId() + ".jpg"));
			}
			userProfileRepository.updateProfile(updateUserProfile);
			return new ResponseDto(0, "Successfully updated profile.");
		} catch (JsonParseException e) {
			LOG.error(e);
			return new ResponseDto(-1, "Error parsing User Profile from input. Please contact support");
		} catch (JsonMappingException e) {
			LOG.error(e);
			return new ResponseDto(-1, "Error parsing User Profile from input. Please contact support");
		} catch (IllegalStateException e) {
			LOG.error(e);
			return new ResponseDto(-1, "Error storing User Profile from input. Please contact support");
		} catch (IOException e) {
			LOG.error(e);
			return new ResponseDto(-1, "Error storing User Profile from input. Please contact support");
		} catch (Exception e) {
			LOG.error(e);
			return new ResponseDto(-1, "Unexpected error while storing user profile. Please contact support");
		}
	}

	@Override
	public ResponseDto updatePasswordService(String userEmail, String password) {
		LOG.debug("Updating password for " + userEmail);
		try {
			userProfileRepository.updatePassword(userEmail, password);
			return new ResponseDto(0, "Updated password successfully.");
		} catch (Exception e) {
			LOG.error(e);
			return new ResponseDto(-1, "Unexpected error while updating password. Please contact support");
		}
	}

	@Override
	public List<UserProfileDto> getUserProfilesForChainService(ChainDto chainDto) {
		LOG.debug("Getting user profiles for chain " + chainDto);
		if (chainDto.getMentorDiscipleInd().equals("M")) {
			return mentorDataRepository.queryByUserEmail(chainDto.getUserEmail(), chainDto.getPageStart(),
					chainDto.getPageEnd());
		} else {
			return discipleDataRepository.queryByUserEmail(chainDto.getUserEmail(), chainDto.getPageStart(),
					chainDto.getPageEnd());
		}
	}

	private void addMentor(String userEmail, String mentorEmail) {
		LOG.debug("Adding " + mentorEmail + " as mentor for " + userEmail);
		MentorData userMentorData = mentorDataRepository.findByUserEmail(userEmail);
		Set<String> userMentorEmailSet = null;
		if (userMentorData == null) {
			userMentorData = new MentorData();
			userMentorData.setUserEmail(userEmail);
			userMentorEmailSet = new HashSet<String>();
		} else {
			userMentorEmailSet = userMentorData.getMentorEmailList();
			if (userMentorEmailSet == null) {
				userMentorEmailSet = new HashSet<String>();
			}
		}
		userMentorEmailSet.add(mentorEmail);
		userMentorData.setMentorEmailList(userMentorEmailSet);
		mentorDataRepository.save(userMentorData);
	}

	private void addDisciple(String userEmail, String discipleEmail) {
		LOG.debug("Adding " + discipleEmail + " as disciple for " + userEmail);
		DiscipleData userDiscipleData = discipleDataRepository.findByUserEmail(userEmail);
		Set<String> userDiscipleEmailSet = null;
		if (userDiscipleData == null) {
			userDiscipleData = new DiscipleData();
			userDiscipleData.setUserEmail(userEmail);
			userDiscipleEmailSet = new HashSet<String>();
		} else {
			userDiscipleEmailSet = userDiscipleData.getDiscipleEmailList();
			if (userDiscipleEmailSet == null) {
				userDiscipleEmailSet = new HashSet<String>();
			}
		}
		userDiscipleEmailSet.add(discipleEmail);
		userDiscipleData.setDiscipleEmailList(userDiscipleEmailSet);
		discipleDataRepository.save(userDiscipleData);
	}

	private void removeMentor(String userEmail, String mentorEmail) {
		LOG.debug("Removing " + mentorEmail + " as mentor for " + userEmail);
		MentorData userMentorData = mentorDataRepository.findByUserEmail(userEmail);
		if (userMentorData != null) {
			Set<String> userMentorEmailSet = userMentorData.getMentorEmailList();
			if (userMentorEmailSet != null) {
				userMentorEmailSet.remove(mentorEmail);
				userMentorData.setMentorEmailList(userMentorEmailSet);
				mentorDataRepository.save(userMentorData);
			}
		}
	}

	private void removeDisciple(String userEmail, String discipleEmail) {
		LOG.debug("Removing " + discipleEmail + " as disciple for " + userEmail);
		DiscipleData userDiscipleData = discipleDataRepository.findByUserEmail(userEmail);
		if (userDiscipleData != null) {
			Set<String> userDiscipleEmailSet = userDiscipleData.getDiscipleEmailList();
			if (userDiscipleEmailSet != null) {
				userDiscipleEmailSet.remove(discipleEmail);
				userDiscipleData.setDiscipleEmailList(userDiscipleEmailSet);
				discipleDataRepository.save(userDiscipleData);
			}
		}
	}

	@Override
	public ResponseDto submitPrayerRequestService(String userEmail, PrayerRequestDto prayerRequestDto) {
		LOG.debug("Submitting prayer request for " + userEmail);
		try {
			PrayerRequest prayerRequest = new PrayerRequest();
			prayerRequest.setUserEmail(userEmail);
			if (Integer.parseInt(prayerRequestDto.getRequestSubmittedAs()) == 1) {
				UserProfile userProfile = userProfileRepository.findByUserEmail(userEmail);
				prayerRequest.setRequestDisplayName(userProfile.getUserDisplayName());
			} else {
				prayerRequest.setRequestDisplayName("Anonymous");
			}
			prayerRequest.setPrayerRequest(prayerRequestDto.getPrayerRequest());
			prayerRequestRepository.save(prayerRequest);
			return new ResponseDto(0, "Successfully added prayer request");
		} catch (NumberFormatException e) {
			LOG.error(e);
			return new ResponseDto(-1, "Invalid input passed from UI");
		} catch (Exception e) {
			LOG.error(e);
			return new ResponseDto(-2, "Error updating prayer request in DB");
		}
	}
}
