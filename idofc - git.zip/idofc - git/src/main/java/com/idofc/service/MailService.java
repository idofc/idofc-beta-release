package com.idofc.service;

import com.idofc.domain.UserProfile;
import com.idofc.dto.ResponseDto;

public interface MailService {

	ResponseDto sendNewUserWelcomeEmail(UserProfile userProfile);

}
