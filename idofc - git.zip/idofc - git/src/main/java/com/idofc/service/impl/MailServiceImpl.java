package com.idofc.service.impl;

import java.util.Locale;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.idofc.domain.UserProfile;
import com.idofc.dto.ResponseDto;
import com.idofc.profile.AppConstants;
import com.idofc.service.MailService;

@Service
public class MailServiceImpl implements MailService {
	final static Logger LOG = Logger.getLogger(MailServiceImpl.class);

	@Autowired
	JavaMailSender javaMailSender;
	@Autowired
	private TemplateEngine templateEngine;
	@Autowired
	private ResponseDto responseDto;

	@Override
	public ResponseDto sendNewUserWelcomeEmail(UserProfile userProfile) {
		String htmlContent;
		try {

			final Locale locale = new Locale("EN");
			final Context ctx = new Context(locale);
			ctx.setVariable("greeting", "Hello " + userProfile.getUserFirstName() + ",");
			ctx.setVariable("validationUrl", "www.google.com");
			final MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			message.setTo(userProfile.getUserEmail());
			message.setSubject(AppConstants.newUserWelcomeSubject);
			htmlContent = templateEngine.process("NewUserWelcome.html", ctx);
			message.setText(htmlContent, true);
			javaMailSender.send(mimeMessage);
		} catch (MailException e) {
			LOG.error("Mail exception occurred " + userProfile);
			e.printStackTrace();
			LOG.error(e);
			responseDto.setReturnCode(-1);
			responseDto.setReturnMsg(e.getLocalizedMessage());
		} catch (MessagingException e) {
			LOG.error("Messaging exception occurred " + userProfile);
			e.printStackTrace();
			LOG.error(e);
			responseDto.setReturnCode(-2);
			responseDto.setReturnMsg(e.getLocalizedMessage());
		}
		responseDto.setReturnCode(0);
		responseDto.setReturnMsg("Successfully sent welcome email");
		return responseDto;
	}
}
