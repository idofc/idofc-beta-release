console.log("Loaded login app.js");

var idofcLoginApp = angular.module('idofcLoginApp', ['ngRoute', 'ngResource'], function ($locationProvider) {
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
});

idofcLoginApp.controller('rootLoginController', ['$scope', '$log', '$location', '$window', function ($scope, $log, $location, $window) {
    $log.debug("Login Root controller - " + $location.search()['source']);
    $log.debug("Window size " + $window.innerHeight + "/" + angular.element("#custom-bootstrap-menu")[0].offsetHeight + "/" + angular.element(".footer")[0].offsetHeight);
    
    $scope.viewHeight = $window.innerHeight -
        angular.element("#custom-bootstrap-menu")[0].offsetHeight -
        angular.element(".footer")[0].offsetHeight;
    $scope.showLogin = true;
    switch ($location.search()['source']) {
    case "activate-success":
        $scope.welcomeHeader = "You're activated. Please sign in to continue!";
        break;
    case "activate-failed":
        $scope.welcomeHeader = "Activation failed. Please contact iDofC support!";
        $scope.showLogin = false;
        break;
    default:
        $scope.welcomeHeader = "Please sign in to continue!";
    }
}]);