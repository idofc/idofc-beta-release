console.log("Loaded register app.js");

var idofcRegisterApp = angular.module('idofcRegisterApp', ['ngRoute', 'ngResource']);

idofcRegisterApp.controller('rootRegisterController', ['$scope', '$log', '$q', '$window', 'UserService',
                                                       function ($scope, $log, $q, $window, UserService) {
        $log.debug("Root register controller");
        $log.debug("Window size " + $window.innerHeight + "/" + angular.element("#custom-bootstrap-menu")[0].offsetHeight + "/" + angular.element(".footer")[0].offsetHeight);


        $scope.viewHeight = $window.innerHeight -
            angular.element("#custom-bootstrap-menu")[0].offsetHeight -
            angular.element(".footer")[0].offsetHeight;

        $scope.newUserRegistration = function () {
            var userDetails = new Object();
            $scope.emailAlreadyExistsErr = false;
            $scope.formProcessingErr = false;
            $scope.formProcessingDone = false;
            $scope.formProcessingMsg = "";
            if (!($scope.userFirstName)) {
                $scope.userRegisterForm.userFirstName.$invalid = true;
                $scope.userRegisterForm.$invalid = true;
            }
            if (!($scope.userLastName)) {
                $scope.userRegisterForm.userLastName.$invalid = true;
                $scope.userRegisterForm.$invalid = true;
            }
            if (!($scope.userDisplayName)) {
                $scope.userRegisterForm.userDisplayName.$invalid = true;
                $scope.userRegisterForm.$invalid = true;
            }
            if (!($scope.userEmail)) {
                $scope.userRegisterForm.userEmail.$invalid = true;
                $scope.userRegisterForm.$invalid = true;
            }
            if (!($scope.userPass)) {
                $scope.userRegisterForm.userPass.$invalid = true;
                $scope.userRegisterForm.$invalid = true;
            }
            if (!($scope.userConfirmPass)) {
                $scope.userRegisterForm.userConfirmPass.$invalid = true;
                $scope.userRegisterForm.$invalid = true;
            }
            if (($scope.userPass) && ($scope.userConfirmPass)) {
                if (!($scope.userPass === $scope.userConfirmPass)) {
                    $scope.userRegisterForm.userConfirmPass.$invalid = true;
                    $scope.userRegisterForm.$invalid = true;
                }
            }

            var checkEmailExistsPromise = $q.defer();
            var addUserPromise = $q.defer();
            var sendNewUserEmailPromise = $q.defer();

            if ($scope.userEmail) {
                checkEmailExistsPromise = UserService.checkEmailExists($scope.userEmail);
                checkEmailExistsPromise.then(function (response) {
                    $log.info("Success calling email");
                    if (response.data === true) {
                        $log.error("Email already exists")
                        $scope.emailAlreadyExistsErr = true;
                        $scope.userRegisterForm.$invalid = true;
                    } else {
                        userDetails.userFirstName = $scope.userFirstName;
                        userDetails.userLastName = $scope.userLastName;
                        userDetails.userDisplayName = $scope.userDisplayName;
                        userDetails.userEmail = $scope.userEmail;
                        userDetails.userPass = $scope.userPass;
                        addUserPromise = UserService.addUser(userDetails);
                        addUserPromise.then(function (response) {
                            $scope.formProcessingDone = true;
                            $scope.formProcessingMsg = "Successfully added you " + $scope.userFirstName + "! Please check your email to validate.";
                            $log.info($scope.formProcessingMsg);
                        }, function (response) {
                            $scope.formProcessingErr = true;
                            $scope.formProcessingMsg = "Sorry " + $scope.userFirstName + "! We are facing some issues now. Please try later.";
                            $log.error(response.data);
                        });
                    }
                }, function (response) {
                    $scope.formProcessingErr = true;
                    $scope.formProcessingMsg = "Error checking validity of Email. Please contact iDofC support.";
                    $log.error($scope.formProcessingMsg);
                });
            }

            $q.all([checkEmailExistsPromise, addUserPromise]).then(function () {
                $log.info("All promises complete");
                if ($scope.emailAlreadyExistsErr === true) {
                    return false;
                }
                return true;
            }, function () {
                $log.info("All promises not complete. Form cannot be submitted");
                return false;
            })
            return false;
        }
}]);