idofcRegisterApp.service('UserService', ['$http', '$rootScope', function ($http, $rootScope) {
    this.checkEmailExists = function (email) {
        console.log("Checking for " + email);
        return $http({
            method: 'POST',
            url: "api/emailexists",
            data: email
        });
    }

    this.addUser = function (userProfile) {
        console.log("Adding user ");
        console.log(userProfile);
        return $http({
            method: 'POST',
            url: "api/adduser",
            data: userProfile
        });
    }

    this.sendNewUserWelcomeEmail = function (userProfile) {
        console.log("Sending new user welcome email ");
        console.log(userProfile);
        return $http({
            method: 'POST',
            url: "api/sendNewUserEmail",
            data: userProfile
        });
    }
}])