idofcPortalApp.controller('profileController', ['$scope', '$rootScope', '$log', '$q', '$location', '$window', 'MentorDiscipleService', 'fileReader', 'UserProfileService',
                        function ($scope, $rootScope, $log, $q, $location, $window, MentorDiscipleService, fileReader, UserProfileService) {
        console.log("Profile controller");
        $log.info($location.path());
        $scope.error = new Object();
        $scope.error.passwordvalid = true;

        $log.debug($rootScope.mentorEmailList);
        $scope.mentorEmailList = new Array();
        $.each($rootScope.mentorEmailList, function (index, mentorEmail) {
            $scope.mentorEmailList.push(mentorEmail);
        });
        //$scope.mentorEmailList = ["a@yahoo.com", "b@yahoo.com"];
        console.log($scope.mentorEmailList.length);

        $scope.updateUserMentorProfile = function () {
            $log.info("Form submitted " + $scope.mentorEmail);
            if (!($scope.mentorEmail)) {
                $scope.messageModalHeader = "Invalid Email";
                $scope.messageModalBody = "Please add a valid mentor email";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
                return false;
            }
            if ($scope.mentorEmailList.indexOf($scope.mentorEmail) === -1) {
                var addMentorPromise = MentorDiscipleService.addMentorService($scope.mentorEmail);
                addMentorPromise.then(function (response) {
                    if (response.data.returnCode === 0) {
                        $log.debug("Success adding mentor!");
                        $log.debug(response);
                        $rootScope.mentorEmailList = $scope.mentorEmailList;
                        $scope.mentorEmailList.push($scope.mentorEmail);
                        $scope.messageModalHeader = "Successfully added mentor";
                        $scope.messageModalBody = "Added " + ($scope.mentorEmail || "someone") + " as your mentor!";
                        $scope.showMessageModal();
                    } else {
                        $log.debug("Return code invalid from add mentor");
                        $log.debug(response);
                        $scope.messageModalHeader = "Adding mentor failed.";
                        $scope.messageModalBody = "Failed adding " + ($scope.mentorEmail || "someone") + " as your mentor. Please contact support.";
                        $scope.messageModalAction1Ind = false;
                        $scope.messageModalAction1 = "";
                        $scope.showMessageModal();
                    }
                }, function (response) {
                    $log.debug("Error adding mentor!");
                    $log.debug(response);
                    $scope.messageModalHeader = "Adding mentor failed.";
                    $scope.messageModalBody = "Failed adding " + ($scope.mentorEmail || "someone") + " as your mentor. Please contact support.";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                })
            } else {
                $scope.messageModalHeader = "Seems you overlooked!";
                $scope.messageModalBody = ($scope.mentorEmail || "someone") + " is already in your mentor list.";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            }
        }

        $scope.removeMentorItem = function (item) {
            console.log("Now removing mentor item");
            console.log(item);
            for (var i = $scope.mentorEmailList.length - 1; i >= 0; i--) {
                if ($scope.mentorEmailList[i] === item) {
                    console.log("deleting mentor item");
                    $scope.mentorEmailList.splice(i, 1);
                    break;
                }
            }
            console.log($rootScope.mentorEmailList);
        }

        $scope.resetMentorList = function () {
            console.log("Now resetting mentor list");
            console.log($scope.mentorEmailList);
            console.log($rootScope.mentorEmailList);
            $scope.mentorEmailList = $rootScope.mentorEmailList;
        }

        $scope.finalizeMentorChanges = function () {
            console.log("Now finalizing mentor list");
            var updateMyMentorListPromise = MentorDiscipleService.updateMyMentorList($scope.mentorEmailList);
            updateMyMentorListPromise.then(function (response) {
                console.log(response);
                if (response.data.returnCode === 0) {
                    $rootScope.mentorEmailList = $scope.mentorEmailList;
                    console.log($rootScope.mentorEmailList);
                    $scope.messageModalHeader = "Mentor list save success";
                    $scope.messageModalBody = "Successfully processed all deletes and saved mentor list. ";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                } else {
                    $log.debug("Return code invalid from update mentor list");
                    $scope.messageModalHeader = "Mentor list save failed";
                    $scope.messageModalBody = "Failed processing all deletes and to save mentor list. ";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                }
            }, function (response) {
                $log.info(response);
                $scope.messageModalHeader = "Mentor list save failed";
                $scope.messageModalBody = "Failed processing all deletes and to save mentor list. ";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            })
        }

        // Start with disciple changes
        $log.debug($rootScope.discipleEmailList);
        $scope.discipleEmailList = new Array();
        $.each($rootScope.discipleEmailList, function (index, discipleEmail) {
            $scope.discipleEmailList.push(discipleEmail);
        });
        //$scope.discipleEmailList = ["a@yahoo.com", "b@yahoo.com"];
        console.log($scope.discipleEmailList.length);

        $scope.updateUserDiscipleProfile = function () {
            $log.info("Form submitted " + $scope.discipleEmail);
            if (!($scope.discipleEmail)) {
                $scope.messageModalHeader = "Invalid Email";
                $scope.messageModalBody = "Please add a valid disciple email";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
                return false;
            }
            if ($scope.discipleEmailList.indexOf($scope.discipleEmail) === -1) {
                var addDisciplePromise = MentorDiscipleService.addDiscipleService($scope.discipleEmail);
                addDisciplePromise.then(function (response) {
                    if (response.data.returnCode === 0) {
                        $log.debug("Success adding disciple!");
                        $log.debug(response);
                        $rootScope.discipleEmailList = $scope.discipleEmailList;
                        $scope.discipleEmailList.push($scope.discipleEmail);
                        $scope.messageModalHeader = "Successfully added disciple";
                        $scope.messageModalBody = "Added " + ($scope.discipleEmail || "someone") + " as your disciple!";
                        $scope.showMessageModal();
                    } else {
                        $log.debug("Return code invalid from add disciple");
                        $log.debug(response);
                        $scope.messageModalHeader = "Adding disciple failed.";
                        $scope.messageModalBody = "Failed adding " + ($scope.discipleEmail || "someone") + " as your disciple. Please contact support.";
                        $scope.messageModalAction1Ind = false;
                        $scope.messageModalAction1 = "";
                        $scope.showMessageModal();
                    }
                }, function (response) {
                    $log.debug("Error adding disciple!");
                    $log.debug(response);
                    $scope.messageModalHeader = "Adding disciple failed.";
                    $scope.messageModalBody = "Failed adding " + ($scope.discipleEmail || "someone") + " as your disciple. Please contact support.";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                })
            } else {
                $scope.messageModalHeader = "Seems you overlooked!";
                $scope.messageModalBody = ($scope.discipleEmail || "someone") + " is already in your disciple list.";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            }
        }

        $scope.removeDiscipleItem = function (item) {
            console.log("Now removing disciple item");
            console.log(item);
            for (var i = $scope.discipleEmailList.length - 1; i >= 0; i--) {
                if ($scope.discipleEmailList[i] === item) {
                    console.log("deleting disciple item");
                    $scope.discipleEmailList.splice(i, 1);
                    break;
                }
            }
            console.log($rootScope.discipleEmailList);
        }

        $scope.resetDiscipleList = function () {
            console.log("Now resetting disciple list");
            console.log($scope.discipleEmailList);
            console.log($rootScope.discipleEmailList);
            $scope.discipleEmailList = $rootScope.discipleEmailList;
        }

        $scope.finalizeDiscipleChanges = function () {
            console.log("Now finalizing disciple list");
            var updateMyDiscipleListPromise = MentorDiscipleService.updateMyDiscipleList($scope.discipleEmailList);
            updateMyDiscipleListPromise.then(function (response) {
                console.log(response);
                if (response.data.returnCode === 0) {
                    $rootScope.discipleEmailList = $scope.discipleEmailList;
                    console.log($rootScope.discipleEmailList);
                    $scope.messageModalHeader = "Disciple list save success";
                    $scope.messageModalBody = "Successfully processed all deletes and saved disciple list. ";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                } else {
                    $log.debug("Return code invalid from update disciple list");
                    $scope.messageModalHeader = "Disciple list save failed";
                    $scope.messageModalBody = "Failed processing all deletes and to save disciple list. ";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                }
            }, function (response) {
                $log.info(response);
                $scope.messageModalHeader = "Disciple list save failed";
                $scope.messageModalBody = "Failed processing all deletes and to save disciple list. ";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            })
        }

        $log.info("Now printing User Profile");
        $log.debug($rootScope.userProfile);
        $scope.userProfile = $rootScope.userProfile;

        //Start with file upload changes
        console.log(fileReader)
        $scope.getFile = function () {
            $scope.progress = 0;
            fileReader.readAsDataUrl($scope.file, $scope)
                .then(function (result) {
                    $scope.imageSrc = result;
                });
        };

        $scope.updateUserProfile = function () {
            console.log("Form submitted");
            if (!(($scope.userProfile.userFirstName) && ($scope.userProfile.userLastName))) {
                $scope.error.userNameInvalid = true;
                return false;
            }
            if (!($scope.userProfile.userDisplayName)) {
                $scope.error.userDisplayNameInvalid = true;
                return false;
            }
            $log.debug($scope.userProfile.userTestimony);
            var userProfileUpdatePromise = UserProfileService.updateUserProfile($scope.userProfile, file.files[0]);
            userProfileUpdatePromise.then(function (response) {
                console.log("Success updating promise");
                console.log(response);
                if (response.data.returnCode === 0) {
                    $scope.messageModalHeader = "Update profile success!";
                    $scope.messageModalBody = "Successfully updated profile and image.";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                } else {
                    $log.error("Return code invalid from update profile");
                    $scope.messageModalHeader = "Update profile failed";
                    $scope.messageModalBody = "Failed processing profile and image. Please contact support.";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                }
            }, function (response) {
                $log.error(response);
                $scope.messageModalHeader = "Update profile failed";
                $scope.messageModalBody = "Failed processing profile and image. Please contact support.";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            });
        }

        $scope.updateUserPassword = function () {
            $log.debug("Submitting form for password update");
            if ($scope.userPassword !== $scope.userConfirmPassword) {
                return false;
            }
            if (!(UserProfileService.checkPassword($scope.userPassword))) {
                return false;
            }
            $log.debug("Now starting to update password");
            var updatePasswordPromise = UserProfileService.updatePassword($scope.userPassword);
            updatePasswordPromise.then(function (response) {
                if (response.data.returnCode === 0) {
                    $scope.messageModalHeader = "Update password success!";
                    $scope.messageModalBody = "Successfully updated user password. Please use your new password next time you login";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                } else {
                    $log.error("Return code invalid from update profile");
                    $scope.messageModalHeader = "Update password failed";
                    $scope.messageModalBody = "Update password failed. Please contact support.";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                }
            }, function (response) {
                $log.error(response);
                $scope.messageModalHeader = "Update password failed";
                $scope.messageModalBody = "Error updating password. Please contact support.";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            });
        }

        $scope.disableAccountClick = function () {
            $log.debug("Disable account");
            $scope.messageModalHeader = "Are you sure?";
            $scope.messageModalBody = "Are you sure you want to disable your account? You will not have access to mentors/disciples going forward.";
            $scope.messageModalAction1Ind = true;
            $scope.messageModalAction1Param = "delete";
            $scope.messageModalAction1 = "Yes, I understand";
            $scope.showMessageModal();
        }

        $scope.messageModalAction1fn = function (param) {
            if (param === "delete") {
                $log.debug("Confirmed to delete");
                $scope.hideMessageModal();
                $window.location.href = '/idofc/logout';
            }
        }

        $scope.checkPasswordRegex = function () {
            $log.debug("Now checking if password is valid " + $scope.userPassword);
            if ($scope.userPassword) {
                $scope.error.passwordvalid = UserProfileService.checkPassword($scope.userPassword);
            }
        }

        $scope.showMessageModal = function () {
            $('#message-modal').modal('show');
        }

        $scope.hideMessageModal = function () {
            $('#message-modal').modal('hide');
        }
}]);