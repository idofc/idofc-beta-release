idofcPortalApp.directive("mentorItem", function () {
    return {
        restrict: 'AE',
        templateUrl: 'pages/portalpage/components/mentor.prt.html',
        scope: {
            mentorObject: '=',
            removeMentorItem: '&'
        }
    }
});

idofcPortalApp.directive("discipleItem", function () {
    return {
        restrict: 'AE',
        templateUrl: 'pages/portalpage/components/disciple.prt.html',
        scope: {
            discipleObject: '=',
            removeDiscipleItem: '&'
        }
    }
});

idofcPortalApp.directive("ngFileSelect", function () {
    return {
        link: function ($scope, el) {
            el.bind("change", function (e) {
                $scope.file = (e.srcElement || e.target).files[0];
                $scope.getFile();
            })
        }
    }
});

idofcPortalApp.directive("chainList", function () {
    return {
        restrict: 'AE',
        templateUrl: 'pages/portalpage/components/chain.prt.html',
        scope: {
            chainObject: '=',
            loadUser: '&'
        }
    }
})