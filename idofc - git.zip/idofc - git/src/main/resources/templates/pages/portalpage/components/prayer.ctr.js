idofcPortalApp.controller('prayerController', ['$scope', '$log', '$q', '$location', '$rootScope', 'PrayerRequestService',
                                              function ($scope, $log, $q, $location, $rootScope, PrayerRequestService) {
        if ($rootScope.userProfile) {
            $scope.currentUserProfile = $rootScope.userProfile;
        } else {
            $log.error("Scope not ready. Redirecting from /prayer to /");
            $location.path("/")
        }

        $scope.submitPrayerRequest = function () {
            $log.debug($scope.requestSubmittedAs);
            $log.debug($scope.prayerRequest);
            var submitPrayerRequestPromise = PrayerRequestService.submitPrayerRequest($scope.requestSubmittedAs, $scope.prayerRequest);
            submitPrayerRequestPromise.then(function (response) {
                if (response.data.returnCode === 0) {
                    $scope.messageModalHeader = "Submit prayer request success!";
                    $scope.messageModalBody = "Prayer request submitted successfully. We'll definitely pray about it.";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                } else {
                    $scope.messageModalHeader = "Submit prayer request failed!";
                    $scope.messageModalBody = "Prayer request submission failed. Please contact support";
                    $scope.messageModalAction1Ind = false;
                    $scope.messageModalAction1 = "";
                    $scope.showMessageModal();
                }
            }, function (response) {
                $scope.messageModalHeader = "Submit prayer request failed!";
                $scope.messageModalBody = "Prayer request submission to backend failed. Please contact support";
                $scope.messageModalAction1Ind = false;
                $scope.messageModalAction1 = "";
                $scope.showMessageModal();
            });
        }

        $scope.showMessageModal = function () {
            $('#message-modal').modal('show');
        }

        $scope.hideMessageModal = function () {
            $('#message-modal').modal('hide');
        }
    }
]);