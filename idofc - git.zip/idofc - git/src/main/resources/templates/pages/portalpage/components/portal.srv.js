idofcPortalApp.service('MentorDiscipleService', ['$http', '$rootScope', '$log', function ($http, $rootScope, $log) {
    this.addMentorService = function (mentorEmail) {
        $log.debug("Adding mentor " + mentorEmail);
        return $http({
            method: 'POST',
            url: "api/addmymentor",
            data: mentorEmail
        });
    }

    this.getMyMentorService = function () {
        $log.debug("Getting my mentors");
        return $http({
            method: 'POST',
            url: "api/getmymentorinfo"
        })
    }

    this.getMentorService = function (userEmail) {
        $log.debug("Getting mentors for " + userEmail);
        return $http({
            method: 'POST',
            url: "api/getmentorinfo",
            data: userEmail
        })
    }

    this.updateMyMentorList = function (mentorEmailList) {
        $log.debug("Resetting mentor list");
        return $http({
            method: 'POST',
            url: "api/updatemymentorlist",
            data: mentorEmailList
        })
    }

    this.addDiscipleService = function (discipleEmail) {
        $log.debug("Adding disciple " + discipleEmail);
        return $http({
            method: 'POST',
            url: "api/addmydisciple",
            data: discipleEmail
        });
    }

    this.getMyDiscipleService = function () {
        $log.debug("Getting my disciples");
        return $http({
            method: 'POST',
            url: "api/getmydiscipleinfo"
        })
    }

    this.getDiscipleService = function (userEmail) {
        $log.debug("Getting disciples for " + userEmail);
        return $http({
            method: 'POST',
            url: "api/getdiscipleinfo",
            data: userEmail
        })
    }

    this.updateMyDiscipleList = function (discipleEmailList) {
        $log.debug("Resetting disciple list");
        return $http({
            method: 'POST',
            url: "api/updatemydisciplelist",
            data: discipleEmailList
        })
    }
}])

idofcPortalApp.service('UserProfileService', ['$http', '$rootScope', '$log', function ($http, $rootScope, $log) {
    this.updateUserProfile = function (userProfile, profilePic) {
        $log.debug("Updating user profile");
        $log.debug(userProfile);
        var formData = new FormData();
        formData.append("profilePic", profilePic);
        formData.append("userProfile", JSON.stringify(userProfile));
        return $http.post('api/updateuserprofile', formData, {
            transformRequest: function (data, headersGetterFunction) {
                return data;
            },
            headers: {
                'Content-Type': undefined
            }
        });
    }

    this.getUserProfile = function () {
        $log.debug("Getting user profile");
        return $http({
            method: 'GET',
            url: 'api/getuserprofile'
        })
    }

    this.getUserProfileByEmail = function (userEmail) {
        $log.debug("Getting user profile by email " + userEmail);
        return $http({
            method: 'POST',
            url: 'api/getuserprofilebyemail',
            data: userEmail
        })
    }

    this.getUserProfileChain = function (userEmail, mentorDiscipleInd, pageStart, pageEnd) {
        $log.debug("Getting user profile by Email");
        var chainDto = new Object();
        chainDto.userEmail = userEmail;
        chainDto.mentorDiscipleInd = mentorDiscipleInd;
        chainDto.pageStart = pageStart;
        chainDto.pageEnd = pageEnd;
        return $http({
            method: 'POST',
            url: 'api/getuserprofilechain',
            data: chainDto
        })
    }

    this.checkPassword = function (password) {
        $log.debug("Checking if password is valid " + password);
        var passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
        if (passwordRegex.test(password)) {
            $log.debug("Password is valid");
            return true;
        } else {
            $log.debug("Password is invalid");
            return false;
        }
    }

    this.updatePassword = function (password) {
        $log.debug("Updating password for current user ");
        return $http({
            method: 'POST',
            url: 'api/updatepassword',
            data: password
        })
    }
}]);

idofcPortalApp.service('PrayerRequestService', ['$http', '$rootScope', '$log', function ($http, $rootScope, $log) {
    $log.debug("Submitting prayer request");
    this.submitPrayerRequest = function (requestSubmittedAs, prayerRequest) {
        var prayerRequestDto = new Object();
        prayerRequestDto.requestSubmittedAs = requestSubmittedAs;
        prayerRequestDto.prayerRequest = prayerRequest;
        return $http({
            method: 'POST',
            url: 'api/submitprayerrequest',
            data: prayerRequestDto
        })
    }
}]);