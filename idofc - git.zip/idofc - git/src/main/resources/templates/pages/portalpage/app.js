console.log("Loaded portal app.js");

var idofcPortalApp = angular.module('idofcPortalApp', ['ui.bootstrap', 'ngRoute', 'ngResource']);

idofcPortalApp.config(function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
        .when('/', {
            templateUrl: 'pages/portalpage/components/home.tpl.html',
            controller: 'homeController'
        })
        .when('/profile', {
            templateUrl: 'pages/portalpage/components/profile.tpl.html',
            controller: 'profileController'
        })
        .when('/chain', {
            templateUrl: 'pages/portalpage/components/chain.tpl.html',
            controller: 'chainController'
        })
        .when('/prayer', {
            templateUrl: 'pages/portalpage/components/prayer.tpl.html',
            controller: 'prayerController'
        })
});

idofcPortalApp.controller('rootPortalController', ['$scope', '$rootScope', '$log', '$q', '$location', '$window', 'MentorDiscipleService', 'UserProfileService',
                            function ($scope, $rootScope, $log, $q, $location, $window, MentorDiscipleService, UserProfileService) {
        console.log("Portal root controller");
        $log.info($location.path());
        $log.debug("Window size " + $window.innerHeight + "/" + angular.element("#custom-bootstrap-menu")[0].offsetHeight + "/" + angular.element(".footer")[0].offsetHeight);

        $scope.viewHeight = $window.innerHeight -
            angular.element("#custom-bootstrap-menu")[0].offsetHeight -
            angular.element(".footer")[0].offsetHeight;

        var getMyMentorInfoPromise = MentorDiscipleService.getMyMentorService();
        getMyMentorInfoPromise.then(function (response) {
            console.log(response);
            $rootScope.mentorEmailList = response.data.mentorEmailList;
            console.log($rootScope.mentorEmailList);
        }, function (data) {
            $log.info(data);
        })

        var getMyDiscipleInfoPromise = MentorDiscipleService.getMyDiscipleService();
        getMyDiscipleInfoPromise.then(function (response) {
            console.log(response);
            $rootScope.discipleEmailList = response.data.discipleEmailList;
            console.log($rootScope.discipleEmailList);
        }, function (data) {
            $log.info(data);
        })

        var getUserProfileInfoPromise = UserProfileService.getUserProfile();
        getUserProfileInfoPromise.then(function (response) {
            $log.debug(response);
            $rootScope.userProfile = response.data;
            $scope.userProfile = $rootScope.userProfile
        }, function (response) {
            $log.info(response);
        })
}]);

idofcPortalApp.controller('homeController', ['$scope', '$log', '$q', '$location', function ($scope, $log, $q, $location) {
    console.log("Home controller");
    $log.info($location.path());
}]);