idofcPortalApp.controller('chainController', ['$scope', '$log', '$q', '$location', '$rootScope', 'UserProfileService', 'MentorDiscipleService',
                                              function ($scope, $log, $q, $location, $rootScope, UserProfileService, MentorDiscipleService) {
        $log.debug("Loading chain controller");
        $log.debug($rootScope.mentorEmailList);
        $log.debug($rootScope.discipleEmailList);
        $log.debug($rootScope.userProfile);
        $log.debug($location.path());

        if (($rootScope.userProfile) && ($rootScope.mentorEmailList) && ($rootScope.discipleEmailList)) {
            $scope.currentUserEmail = $rootScope.userProfile.userEmail;
            $scope.currentUserProfile = $rootScope.userProfile;
            $scope.currentUserMentorEmailList = $rootScope.mentorEmailList;
            $scope.currentUserDiscipleEmailList = $rootScope.discipleEmailList;
        } else {
            $log.error("Scope not ready. Redirecting from /chain to /");
            $location.path("/")
        }

        $scope.chainList = new Array();

        $scope.loadUser = function (user) {
            $log.debug("loading new user");
            $log.debug(user);
            $scope.currentUserEmail = user.userEmail;
            var getUserProfileInfoPromise = UserProfileService.getUserProfileByEmail(user.userEmail);
            getUserProfileInfoPromise.then(function (response) {
                $log.debug(response);
                $scope.currentUserProfile = response.data;
            }, function (response) {
                $log.error(response);
            })

            var getMentorInfoPromise = MentorDiscipleService.getMentorService(user.userEmail);
            getMentorInfoPromise.then(function (response) {
                $log.debug(response);
                $scope.currentUserMentorEmailList = response.data.mentorEmailList;
                $log.debug("Printing mentor results");
                $log.debug($rootScope.mentorEmailList);
                $log.debug($scope.currentUserMentorEmailList)
            }, function (data) {
                $log.error(data);
            })

            var getDiscipleInfoPromise = MentorDiscipleService.getDiscipleService(user.userEmail);
            getDiscipleInfoPromise.then(function (response) {
                $log.debug(response);
                $scope.currentUserDiscipleEmailList = response.data.discipleEmailList;
                $log.debug("Printing disciple results");
                $log.debug($rootScope.discipleEmailList);
                $log.debug($scope.currentUserDiscipleEmailList);
            }, function (data) {
                $log.error(data);
            })

            $q.all([getUserProfileInfoPromise, getMentorInfoPromise, getDiscipleInfoPromise]).then(function (response) {
                $scope.showResultsInd = false;
                $log.debug(response);
            }, function (response) {
                $log.error("Error fullfilling all promises");
                $log.error(response);
            });
        }

        $scope.showMentors = function () {
            $scope.mentorEmailList = new Array();
            $.each($scope.currentUserMentorEmailList, function (index, mentorEmail) {
                $scope.mentorEmailList.push(mentorEmail);
            });
            $scope.currentPageSet = 0;
            $log.debug($scope.mentorEmailList.length);
            $scope.totalPageSets = Math.floor($scope.mentorEmailList.length / 4);
            if ($scope.mentorEmailList.length > 0) {
                if (($scope.mentorEmailList.length % 4) === 0) {
                    $scope.totalPageSets--;
                }
                $log.debug("Total page sets " + $scope.totalPageSets);
                $scope.mentorDiscipleInd = "M";
                $scope.showPageResults($scope.currentUserEmail, $scope.mentorDiscipleInd, 0, 3);
            } else {
                $scope.totalPageSets = 0;
                $scope.chainList = [];
            }
        }

        $scope.showDisciples = function () {
            $scope.discipleEmailList = new Array();
            $.each($scope.currentUserDiscipleEmailList, function (index, discipleEmail) {
                $scope.discipleEmailList.push(discipleEmail);
            });
            $scope.currentPageSet = 0;
            $log.debug($scope.discipleEmailList.length);
            if ($scope.discipleEmailList.length > 0) {
                $scope.totalPageSets = Math.floor($scope.discipleEmailList.length / 4);
                if (($scope.discipleEmailList.length % 4) === 0) {
                    $scope.totalPageSets--;
                }
                $log.debug("Total page sets " + $scope.totalPageSets);
                $scope.mentorDiscipleInd = "D";
                $scope.showPageResults($scope.currentUserEmail, $scope.mentorDiscipleInd, 0, 3);
            } else {
                $scope.totalPageSets = 0;
                $scope.chainList = [];
            }
        }

        $scope.nextPage = function () {
            $log.debug("Showing next page");
            $scope.currentPageSet++;
            var pageStart = $scope.currentPageSet * 4;
            var pageEnd = (($scope.currentPageSet + 1) * 4) - 1;
            $scope.showPageResults($scope.currentUserEmail, $scope.mentorDiscipleInd, pageStart, pageEnd);
        }

        $scope.prevPage = function () {
            $log.debug("Showing prev page");
            $scope.currentPageSet--;
            var pageStart = $scope.currentPageSet * 4;
            var pageEnd = (($scope.currentPageSet + 1) * 4) - 1;
            $scope.showPageResults($scope.currentUserEmail, $scope.mentorDiscipleInd, pageStart, pageEnd);
        }

        $scope.showPageResults = function (userEmail, mentorDiscipleInd, pageStart, pageEnd) {
            var getChainResultPromise = UserProfileService.getUserProfileChain(userEmail, mentorDiscipleInd, pageStart, pageEnd);
            getChainResultPromise.then(function (response) {
                $log.debug("Success getting chain details");
                $log.debug(response.data);
                $scope.chainList = response.data;
                $scope.showResultsInd = true;
            }, function (response) {
                $log.error("Failed getting chain details");
                $log.error(response);
            });
        }
}]);